package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 * This class create a GUI view for admin's home page.
 * @author Jayden Tan
 * @version 1.0
 */
public class AdminHomePage extends JFrame {
	/**
	 * a JPanel contains other GUI components
	 */
	private JPanel contentPane;
        
        /**
	 * the JTable shows a list of item information
	 */
	private JTable table;
        
        /**
	 * text field for category
	 */
	private JTextField categoryTextField;
        
        /**
	 * text field for item name
	 */
	private JTextField itemNameTextField;
        
        /**
	 * text field for quantity
	 */
	private JTextField qtyTextField;
        
        /**
	 * text field for optimal quantity
	 */
	private JTextField optimalTextField;
        
        /**
	 * default table model store data(items) for each row
	 */
	private DefaultTableModel model;
        
        /**
	 * text field for value
	 */
	private JTextField valueTextField;
        
        /**
	 * text field for value
	 */
	private JLabel valueLabel;
        
        /**
	 * the back button
	 */
	private JButton backButton;
        
        /**
	 * the log out button
	 */
	private JButton logOutButton;
        
        /**
	 * the clear button
	 */
	private JButton clearButton;
        
        /**
	 * the add button
	 */
	private JButton addButton;
        
        /**
	 * the update button
	 */
	private JButton updateButton;
        
        /**
	 * the delete button
	 */
	private JButton deleteButton;

	/**
	 * Create the frame view and initialize the admin home page.
	 */
	public AdminHomePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
		setBounds(100, 100, 600, 553);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
                
		createFunctionalityButtons(contentPane);
		createSubFunctionalityButtons(contentPane);
		setUpTable(contentPane);
		setUpItemLabelField(contentPane);
	}

      
	/**
	 * this method set up the labels and text fields
	 *  for category, item name, quantity, optimal quantity
	 * @param contentPane -JPanel contains other GUI components
	 */
	private void setUpItemLabelField(JPanel contentPane) {
		//category label
		JLabel categoryLabel = new JLabel("Category");
		categoryLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		categoryLabel.setBounds(6, 322, 84, 16);
		contentPane.add(categoryLabel);
		
		//item name label
		JLabel itemNameLabel = new JLabel("Item Name");
		itemNameLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		itemNameLabel.setBounds(6, 355, 84, 16);
		contentPane.add(itemNameLabel);
		
		//quantity label
		JLabel quantityLabel = new JLabel("Quantity");
		quantityLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		quantityLabel.setBounds(5, 388, 85, 16);
		contentPane.add(quantityLabel);
		
		//optimal quantity label
		JLabel optimalQtyLabel = new JLabel("Optimlal Qty");
		optimalQtyLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		optimalQtyLabel.setBounds(5, 421, 84, 16);
		contentPane.add(optimalQtyLabel);
		
		//category text field
		categoryTextField = new JTextField();
		categoryTextField.setBounds(102, 317, 130, 26);
		contentPane.add(categoryTextField);
		categoryTextField.setColumns(10);
		
		//item name text field
		itemNameTextField = new JTextField();
		itemNameTextField.setBounds(102, 350, 130, 26);
		contentPane.add(itemNameTextField);
		itemNameTextField.setColumns(10);
		
		//quantity text field
		qtyTextField = new JTextField();
		qtyTextField.setBounds(102, 383, 130, 26);
		contentPane.add(qtyTextField);
		qtyTextField.setColumns(10);
		
		//optimal quantity text field
		optimalTextField = new JTextField();
		optimalTextField.setBounds(101, 416, 130, 26);
		contentPane.add(optimalTextField);
		optimalTextField.setColumns(10);
		
                //value label
		valueLabel = new JLabel("Value");
		valueLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		valueLabel.setBounds(29, 449, 61, 16);
		contentPane.add(valueLabel);
                
                //value text field
                valueTextField = new JTextField();
		valueTextField.setBounds(101, 444, 130, 26);
		contentPane.add(valueTextField);
		valueTextField.setColumns(10);
	}
	
/**
 * Set up the JTable with the item data loaded initially
 * and set up the scroll pane surround the JTable
 * @param contentPane - JPanel contains other GUI components
 */
	private void setUpTable(JPanel contentPane){
		

		//create a scroll pane surround the JTable
		//the table is inside the scroll pane
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 41, 580, 269);
		contentPane.add(scrollPane);
		
		//create the JTable with given data and column information
		model = new DefaultTableModel();
		table = new JTable(model);
                
                //makesure each cell is uneditable
		table.setDefaultEditor(Object.class, null);
		
		scrollPane.setViewportView(table);
	}
 
/**
 * create a list of buttons which is irrelevant to the data
 * the buttons are [home] [log out]
 * @param contentPane - JPanel contains other GUI components
 */
	private void createSubFunctionalityButtons(JPanel contentPane) {
		
		
		//back button
		backButton = new JButton("Home");
		backButton.setBounds(0, 0, 75, 29);
		contentPane.add(backButton);
		
		//log out button
		logOutButton = new JButton("Log Out");
		logOutButton.setBounds(491, 479, 94, 46);
		contentPane.add(logOutButton);
	}
	
/**
 * Create a list of functional button to support admin's manipulate item data
 * the list of buttons are [Clear] [Add] [Update] [Delete]
 * @param contentPane - JPanel contains other GUI components
 */
	private void createFunctionalityButtons(JPanel contentPane) {
		
		//clear button
		clearButton = new JButton("Clear");
		clearButton.setBounds(244, 317, 117, 29);
		contentPane.add(clearButton);
		
		//add button
		addButton = new JButton("Add");
		addButton.setBounds(244, 350, 117, 29);
		contentPane.add(addButton);
		
		//update button
		updateButton = new JButton("Update");
		updateButton.setBounds(244, 383, 117, 29);
		contentPane.add(updateButton);
		
		//delete button
		deleteButton = new JButton("Delete");
		deleteButton.setBounds(243, 416, 117, 29);
		contentPane.add(deleteButton);
	}
	
        
	/**
	 * reset the every text field to an empty string text field.
	 */
	public void emptyTextField() {
		categoryTextField.setText("");
		itemNameTextField.setText("");
		qtyTextField.setText("");
		optimalTextField.setText("");
		valueTextField.setText("");
	}
	

	/**
	 * getter for home button
	 * @return backButton
	 */
	public JButton getBackButton() {
		return backButton;
	}
	
        /**
	 * getter for log out button
	 * @return logOutButton
	 */
	public JButton getLogOutButton(){
		return logOutButton;
	}
	
        /**
	 * getter for clear button
	 * @return clearButton
	 */
	public JButton getClearButton(){
		return clearButton;
	}
	
        /**
	 * getter for add button
	 * @return addButton
	 */
	public JButton getAddButton(){
		return addButton;
	}
	
        /**
	 * getter for update button
	 * @return updateButton
	 */
	public JButton getUpdateButton(){
		return updateButton;
	}
	
        /**
	 * getter for delete button
	 * @return deleteButton
	 */
	public JButton getDeleteButton(){
		return deleteButton;
	}
	
        /**
	 * getter for the Jtable
	 * @return table
	 */
	public JTable getTable(){
		return table;
	}
	
        /**
	 * getter category text field
	 * @return categoryTextField
	 */
	public JTextField getCategoryTextField(){
		return categoryTextField;
	}
	
        /**
	 * getter for item name text field
	 * @return itemNameTextField
	 */
	public JTextField getItemNameTextField(){
		return itemNameTextField;
	}
	
        /**
	 * getter for  quantity text field
	 * @return qtyTextField
	 */
	public JTextField getQtyTextField(){
		return qtyTextField;
	}
	
        /**
	 * getter for optimal quantity text field
	 * @return optimalTextField
	 */
	public JTextField getOptimalTextField(){
		return optimalTextField;
	}
	
        /**
	 * getter for value text field
	 * @return valueTextField
	 */
	public JTextField getValueTextField(){
		return valueTextField;
	}
	
        /**
	 * getter for contentPane
	 * @return contentPane - JPanel contains other GUI components
	 */
	public JPanel getContentPane(){
		return contentPane;
	}
	
        /**
	 * getter for default table model
	 * @return model contains the data for item list
         * that will used for display in the J table
	 */
	public DefaultTableModel getModel(){
		return model;
	}
	
}