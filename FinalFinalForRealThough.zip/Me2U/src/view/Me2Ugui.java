package view;
import javax.swing.*;
import java.awt.*;

/**
 * This is the homepage gui that initialize the homepage view of Me2U project.
 * @author Ziliang Wang
 */
public class Me2Ugui {
    /**Set north panel. */
    private final JPanel myNorthPanel = new JPanel();
    private final int PADDING = 30;  
    private final JButton dButton = new JButton("Donations"); 
    private JButton rButton = new JButton("Receive Aid");
    private JFrame frame;
    private JComponent southPanel;
    private NewsPanel news;
    private JPopupMenu popupD;
    private JPopupMenu popupR;
    private JMenuItem reqAidItem;
    private JMenuItem donateItem;
    private JButton logoutButton;
    private JButton adminButton;
    private JLabel nameLabel;
    private JMenuItem howToDonateItem;
    private JMenuItem volunteerItem;
    private JMenuItem pickupEligibilityItem;
    private JMenuItem itemsWeTakeItem;
    private JMenuItem eligibilityItem;
    /**
     * This is default constructor.
     */
    public Me2Ugui() {
    	initialize();  	
    }
    /**
     * Initialize the gui and make the frame visible.
     */
    private void initialize() {
        frame = new JFrame("Me 2 U");
        frame.setPreferredSize(new Dimension(720, 480));
        frame.setBackground(Color.WHITE);        
        southPanel = new JPanel();
        southPanel.setBackground(Color.WHITE);
        news = new NewsPanel();
        news.setBackground(Color.LIGHT_GRAY);
        news.setPreferredSize(new Dimension(200, 400));
        final MostNeededItemPanel moi = new MostNeededItemPanel();
        moi.setBackground(Color.RED);
        moi.setPreferredSize(new Dimension(200, 400));
        final LeaderBoardPanel lbp = new LeaderBoardPanel();
        lbp.setBackground(Color.CYAN);
        lbp.setPreferredSize(new Dimension(200, 400));     
        final Box centerBox = new Box(BoxLayout.LINE_AXIS);
        centerBox.add(news);
        centerBox.add(Box.createHorizontalStrut(PADDING));
        centerBox.add(moi);
        centerBox.add(Box.createHorizontalStrut(PADDING));
        centerBox.add(lbp);
        southPanel.add(centerBox);   
        frame.getContentPane().add(getNorthPanel(), BorderLayout.NORTH);
        frame.add(southPanel, BorderLayout.CENTER);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
    }
    /**
     * This is setup the north panel of the homepage gui.
     * @return a JPanel
     */
    private JPanel getNorthPanel() {
        myNorthPanel.add(createDonationButton());
        myNorthPanel.add(createRecipientButton());
        nameLabel = new JLabel("User");
        myNorthPanel.add(nameLabel);
        logoutButton = new JButton("Logout");
        myNorthPanel.add(logoutButton);
        adminButton = new JButton("Admin Page");
        adminButton.setVisible(false);
        myNorthPanel.add(adminButton);
        myNorthPanel.setLayout(new FlowLayout(FlowLayout.LEFT));  
		return myNorthPanel;
    }
    /**
     * To create a series buttons for donation drop down.
     * @return a list of button.
     */
    private JButton createDonationButton() {
        popupD = new JPopupMenu();
        howToDonateItem = new JMenuItem("How To Donate");
        popupD.add(howToDonateItem);
        popupD.addSeparator();
        volunteerItem = new JMenuItem("Volunteering");
        popupD.add(volunteerItem);
        popupD.addSeparator();
        pickupEligibilityItem = new JMenuItem("Pick Up Eligibility");
        popupD.add(pickupEligibilityItem);
        popupD.addSeparator();
        itemsWeTakeItem = new JMenuItem("Items We Take");
        popupD.add(itemsWeTakeItem);
        popupD.addSeparator();
        donateItem = new JMenuItem("Donate Now!");
        popupD.add(donateItem);
        return dButton;
    } 
    /**
     * Generate a list buttons for recipient.
     * @return a button.
     */
    private JButton createRecipientButton() {   
        popupR = new JPopupMenu();
        eligibilityItem = new JMenuItem("Eligibility");
        popupR.add(eligibilityItem);
        popupR.addSeparator();    
        popupR.add(new JMenuItem("Package Options")); 
        popupR.addSeparator();
        reqAidItem = new JMenuItem("Request Aid!");
        popupR.add(reqAidItem);
        return rButton;
    }
    /**
     * Getters for make homepage view.
     * @return 
     */
    public JMenuItem getReqAidItem() {
        return reqAidItem;
    }
    public JMenuItem getDonateItem() {
        return donateItem;
    }
    
    public JMenuItem getHowToDonateItem() {
        return howToDonateItem;
    }

    public JMenuItem getVolunteerItem() {
        return volunteerItem;
    }

    public JMenuItem getPickUpEligibilityItem() {
        return pickupEligibilityItem;
    }

    public JMenuItem getItemsWeTakeItem() {
        return itemsWeTakeItem;
    }
    
        public JMenuItem getEligibilityItem() {
        return eligibilityItem;
    }
    public JPopupMenu getPopupR() {
        return popupR;
    }
    public JPopupMenu getPopupD() {
        return popupD;
    }
    public JFrame getFrame() {
        return frame;
    }
    public JButton getdButton() {
        return dButton;
    }
    public JButton getrButton() {
        return rButton;
    }
    public JLabel getNameLabel() {
        return nameLabel;
    }
    public JButton getLogoutButton() {
        return logoutButton;
    }
    public JButton getAdminButton() {
        return adminButton;
    }
}