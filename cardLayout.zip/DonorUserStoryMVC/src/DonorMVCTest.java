
import controller.DonorController;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sonny
 */
public class DonorMVCTest{
    CardLayout card = new CardLayout();
       JPanel contentPane = new JPanel();
       JFrame frame = new JFrame();
       LoginTestLol login;
       
       public DonorMVCTest(){

       contentPane.setLayout(card);
       login = new LoginTestLol();
       JButton button;
       button = login.getButtonLol();
 
       button.addMouseListener(new java.awt.event.MouseAdapter() {
               @Override
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                   mouseLolPerformed(evt);
               }
           });
       contentPane.add(login, "1");
      
       card.show(contentPane, "1");
         frame.add(contentPane);
       frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    frame.setPreferredSize(login.getPreferredSize());
     frame.pack();  
             frame.setLocationRelativeTo(null);
    frame.setResizable(false);
       frame.setVisible(true);
       }
       
       public Dimension getLoginLolPref(){
           return this.login.getPreferredSize();
       }
    public static void main(String[] args){

       java.awt.EventQueue.invokeLater(new Runnable() {
           @Override
           public void run() {
                new DonorMVCTest();
           }
       });
    }
   
    public void mouseLolPerformed(MouseEvent e) {  
         
          DonorController controller = new DonorController();
          JButton backButton = controller.getBackButton();
          backButton.addMouseListener(new java.awt.event.MouseAdapter() {
               @Override
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                   mouseBackLolPerformed(evt);
               }
           });
          contentPane.add(controller.getDonorView(), "2");
          card.show(contentPane, "2");
            frame.setPreferredSize(new Dimension(1200, 800));
            frame.pack();
            frame.setLocationRelativeTo(null);
    }  
    
    public void mouseBackLolPerformed(MouseEvent e){
        card.show(contentPane, "1");
        frame.setPreferredSize(getLoginLolPref());
            frame.pack();
            frame.setLocationRelativeTo(null);
    }
}
